import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { IntelligenceArtifacts } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        decisions: {
            type: Type.ARRAY,
            description: "A list of key decisions made.",
            items: {
                type: Type.OBJECT,
                properties: {
                    decision: { type: Type.STRING, description: "A concise summary of the decision." },
                    date: { type: Type.STRING, description: "The date the decision was made (YYYY-MM-DD), if available." },
                    context: { type: Type.STRING, description: "Brief context or reason for the decision." },
                },
                required: ["decision", "context"],
            },
        },
        actionItems: {
            type: Type.ARRAY,
            description: "A list of action items or tasks.",
            items: {
                type: Type.OBJECT,
                properties: {
                    task: { type: Type.STRING, description: "The specific task to be completed." },
                    assignee: { type: Type.STRING, description: "The person or team responsible. 'Unassigned' if not specified." },
                    dueDate: { type: Type.STRING, description: "The due date (YYYY-MM-DD), if available. 'N/A' if not specified." },
                },
                required: ["task", "assignee"],
            },
        },
        timelineEvents: {
            type: Type.ARRAY,
            description: "A chronological list of important events, milestones, or meetings.",
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "Date of the event (YYYY-MM-DD)." },
                    event: { type: Type.STRING, description: "A summary of the event." },
                    type: { type: Type.STRING, description: "Type of event: 'decision', 'milestone', 'meeting', or 'upload'."},
                },
                required: ["date", "event", "type"],
            },
        },
        people: {
            type: Type.ARRAY,
            description: "Profiles of people mentioned and their inferred expertise.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Full name of the person." },
                    expertise: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of topics or areas of expertise." },
                    mentionedIn: { type: Type.INTEGER, description: "Number of times this person was mentioned."}
                },
                required: ["name", "expertise"],
            },
        },
        glossary: {
            type: Type.ARRAY,
            description: "A list of acronyms, jargon, and their definitions.",
            items: {
                type: Type.OBJECT,
                properties: {
                    term: { type: Type.STRING, description: "The acronym or jargon." },
                    definition: { type: Type.STRING, description: "The definition of the term." },
                },
                required: ["term", "definition"],
            },
        },
        qaPairs: {
            type: Type.ARRAY,
            description: "A list of questions and their corresponding answers found in the text.",
            items: {
                type: Type.OBJECT,
                properties: {
                    question: { type: Type.STRING, description: "A question asked in the text." },
                    answer: { type: Type.STRING, description: "The corresponding answer." },
                },
                required: ["question", "answer"],
            },
        },
        references: {
          type: Type.ARRAY,
          description: "A list of external URLs or document links mentioned.",
          items: {
            type: Type.OBJECT,
            properties: {
              url: { type: Type.STRING, description: "The full URL." },
              description: { type: Type.STRING, description: "Brief description of what the link points to." },
            },
            required: ["url", "description"],
          }
        }
    },
};


export const processContent = async (
    content: string | { type: 'image'; data: string; mimeType: string },
    fileName: string
): Promise<IntelligenceArtifacts> => {
    try {
        const systemInstruction = `You are an AI knowledge extraction engine. Your task is to analyze the provided content from a document named "${fileName}" and structure it into a comprehensive set of knowledge artifacts.
- Adhere strictly to the provided JSON schema.
- If a category (like decisions, actionItems, etc.) has no relevant items in the text, you MUST return an empty array for that key. Do not omit any keys from the schema.
- For 'decisions', identify clear statements of choice or resolution. For example, "We will proceed with Option A" or "It was decided to postpone the launch."
- For 'qaPairs', look for explicit questions followed by their corresponding answers.
- For 'timelineEvents', base all dates on any dates mentioned in the text.
- For 'people', identify individuals by their full name if possible.`;
        
        let contents;
        if (typeof content === 'string') {
             contents = `Analyze the following text from the document "${fileName}":\n\n${content}`;
        } else {
            contents = {
                parts: [
                    {
                        inlineData: {
                            mimeType: content.mimeType,
                            data: content.data,
                        },
                    },
                    {
                        text: `This is an image from the document "${fileName}". Perform OCR to extract all text, then analyze the extracted text to generate the knowledge artifacts.`,
                    },
                ],
            };
        }
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema,
                temperature: 0.2,
            }
        });

        const text = response.text.trim();
        const artifacts = JSON.parse(text) as IntelligenceArtifacts;
        
        // Basic validation
        if (!artifacts || typeof artifacts !== 'object') {
            throw new Error("Parsed response is not a valid object.");
        }

        return artifacts;
    } catch (error) {
        console.error("Error processing content with Gemini:", error);
        throw new Error("Failed to extract knowledge artifacts from the content.");
    }
};