import React from 'react';
import { CheckIcon } from './icons';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50 transition-opacity"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div 
        className="bg-gray-800 rounded-lg border border-gray-700 shadow-xl p-6 m-4 max-w-sm w-full text-center transform transition-all"
        onClick={e => e.stopPropagation()} // Prevent click inside modal from closing it
      >
        <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-800">
            <CheckIcon className="h-7 w-7 text-green-300" />
        </div>
        <div className="mt-3 text-center sm:mt-5">
          <h3 className="text-xl leading-6 font-bold text-white" id="modal-title">
            Knowledge Unlocked!
          </h3>
          <div className="mt-2">
            <p className="text-sm text-gray-400">
              Your document has been processed. Dive in and explore the generated insights.
            </p>
          </div>
        </div>
        <div className="mt-5 sm:mt-6">
          <button
            type="button"
            className="inline-flex justify-center w-full rounded-md border border-transparent shadow-sm px-4 py-2 bg-brand-blue text-base font-medium text-white hover:bg-brand-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-brand-accent sm:text-sm"
            onClick={onClose}
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};
