import React, { useState, useRef, useCallback } from 'react';
import { PhotoIcon, UploadIcon, Spinner } from './icons';
import { Document } from '../types';

interface IngestionViewProps {
    // FIX: Update onAddDocument prop to accept an optional mimeType for image uploads.
    onAddDocument: (document: Omit<Document, 'id' | 'artifacts' | 'processed' | 'createdAt'> & { mimeType?: string }) => void;
    isLoading: boolean;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
};

const readTextFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

export const IngestionView: React.FC<IngestionViewProps> = ({ onAddDocument, isLoading }) => {
    const [textInput, setTextInput] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);
    const imageInputRef = useRef<HTMLInputElement>(null);

    const handleProcessText = () => {
        if (textInput.trim()) {
            onAddDocument({
                name: `Pasted Text - ${new Date().toLocaleString()}`,
                type: 'text',
                content: textInput,
            });
            setTextInput('');
        }
    };

    // FIX: Replaced for...of loop with a standard for loop to fix type inference issues where `file` was treated as `unknown`.
    const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (!files) return;

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            if (file.type.startsWith('text/') || file.name.endsWith('.md')) {
                const content = await readTextFile(file);
                onAddDocument({ name: file.name, type: 'text', content });
            } else {
                alert(`File type for "${file.name}" not supported for text extraction. Only text-based files are currently supported.`);
            }
        }
    }, [onAddDocument]);
    
    // FIX: Pass the file's mime type when adding an image document to avoid hardcoding it later.
    const handleImageUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (!files || files.length === 0) return;
        
        const file = files[0];
        const content = await fileToBase64(file);
        onAddDocument({ name: file.name, type: 'image', content, mimeType: file.type });

    }, [onAddDocument]);

    return (
        <div className="p-4 bg-gray-800 rounded-lg border border-gray-700">
            <h3 className="text-lg font-semibold text-gray-200 mb-2">Add Knowledge</h3>
            <p className="text-sm text-gray-400 mb-4">Paste meeting notes, chat logs, or upload documents to build your project's memory.</p>
            
            <div className="bg-gray-900 rounded-lg p-1">
                <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder=" Paste any text here...."
                    className="w-full h-48 p-3 bg-gray-900 text-gray-200 border border-gray-700 rounded-md focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition"
                    disabled={isLoading}
                />
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                    <input type="file" ref={fileInputRef} onChange={handleFileUpload} multiple className="hidden" accept=".txt,.md,text/plain" />
                    <button onClick={() => fileInputRef.current?.click()} disabled={isLoading} className="flex items-center gap-2 px-4 py-2 bg-gray-700 text-gray-200 rounded-md hover:bg-gray-600 transition disabled:opacity-50">
                        <UploadIcon className="w-5 h-5" />
                        Upload Files
                    </button>

                    <input type="file" ref={imageInputRef} onChange={handleImageUpload} className="hidden" accept="image/jpeg,image/png,image/webp" />
                     <button onClick={() => imageInputRef.current?.click()} disabled={isLoading} className="flex items-center gap-2 px-4 py-2 bg-gray-700 text-gray-200 rounded-md hover:bg-gray-600 transition disabled:opacity-50">
                        <PhotoIcon className="w-5 h-5" />
                        Upload Image
                    </button>
                </div>

                <button 
                    onClick={handleProcessText} 
                    disabled={isLoading || !textInput.trim()}
                    className="flex items-center justify-center gap-2 px-6 py-2 bg-brand-blue text-white font-semibold rounded-md hover:bg-brand-accent transition disabled:opacity-50 disabled:cursor-not-allowed w-full sm:w-auto"
                >
                    {isLoading ? <Spinner /> : 'Process Text'}
                </button>
            </div>
        </div>
    );
};