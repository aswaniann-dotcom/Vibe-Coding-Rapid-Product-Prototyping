
import React from 'react';
import { IntelligenceArtifacts, ArtifactType } from '../types';

interface ArtifactViewProps {
  artifacts: IntelligenceArtifacts;
  activeTab: ArtifactType;
}

const Card: React.FC<{children: React.ReactNode; className?: string}> = ({ children, className }) => (
    <div className={`bg-gray-800 p-4 rounded-lg border border-gray-700 shadow-md ${className}`}>
        {children}
    </div>
);

const TimelineView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="space-y-6">
        {artifacts.timelineEvents.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((event, i) => (
            <div key={i} className="relative pl-8">
                <div className="absolute left-0 top-1.5 w-4 h-4 bg-brand-accent rounded-full border-4 border-gray-800"></div>
                <div className="absolute left-[7px] top-6 h-full w-0.5 bg-gray-700"></div>
                <p className="font-mono text-sm text-gray-400">{event.date}</p>
                <p className="font-semibold text-gray-200">{event.event}</p>
                <p className="text-sm capitalize text-brand-accent">{event.type}</p>
            </div>
        ))}
    </div>
);

const DecisionsView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {artifacts.decisions.map((d, i) => (
            <Card key={i}>
                <p className="font-semibold text-gray-200">{d.decision}</p>
                <p className="text-sm text-gray-400 mt-2">{d.context}</p>
                <p className="text-xs font-mono text-right mt-3 text-brand-accent">{d.date}</p>
            </Card>
        ))}
    </div>
);

const ActionItemsView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
     <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-800">
                <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-200 sm:pl-6">Task</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-200">Assignee</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-200">Due Date</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-gray-700 bg-gray-900">
                {artifacts.actionItems.map((item, i) => (
                    <tr key={i}>
                        <td className="whitespace-normal py-4 pl-4 pr-3 text-sm font-medium text-gray-200 sm:pl-6">{item.task}</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-400">{item.assignee}</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-400 font-mono">{item.dueDate}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);


const ExpertsView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {artifacts.people.map((p, i) => (
            <Card key={i} className="text-center">
                <p className="font-bold text-lg text-brand-accent">{p.name}</p>
                <div className="mt-2 flex flex-wrap justify-center gap-1">
                    {p.expertise.map((e, j) => (
                        <span key={j} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">{e}</span>
                    ))}
                </div>
            </Card>
        ))}
    </div>
);

const GlossaryView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="space-y-4">
        {artifacts.glossary.map((g, i) => (
            <Card key={i}>
                <p><strong className="text-brand-accent">{g.term}:</strong> {g.definition}</p>
            </Card>
        ))}
    </div>
);

const FAQView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="space-y-4">
        {artifacts.qaPairs.map((qa, i) => (
            <Card key={i}>
                <p className="font-semibold text-gray-400">Q: {qa.question}</p>
                <p className="mt-2 text-gray-200">A: {qa.answer}</p>
            </Card>
        ))}
    </div>
);

const ReferencesView: React.FC<{ artifacts: IntelligenceArtifacts }> = ({ artifacts }) => (
    <div className="space-y-4">
        {artifacts.references.map((r, i) => (
            <Card key={i}>
                <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-brand-accent hover:underline break-all">{r.url}</a>
                <p className="text-sm text-gray-400 mt-1">{r.description}</p>
            </Card>
        ))}
    </div>
);


export const ArtifactsDisplay: React.FC<ArtifactViewProps> = ({ artifacts, activeTab }) => {
    const renderView = () => {
        switch (activeTab) {
            case ArtifactType.Timeline: return <TimelineView artifacts={artifacts} />;
            case ArtifactType.Decisions: return <DecisionsView artifacts={artifacts} />;
            case ArtifactType.ActionItems: return <ActionItemsView artifacts={artifacts} />;
            case ArtifactType.Experts: return <ExpertsView artifacts={artifacts} />;
            case ArtifactType.Glossary: return <GlossaryView artifacts={artifacts} />;
            case ArtifactType.FAQ: return <FAQView artifacts={artifacts} />;
            case ArtifactType.References: return <ReferencesView artifacts={artifacts} />;
            default: return <p>Select an artifact type to view.</p>;
        }
    };
    
    return <div className="mt-6">{renderView()}</div>;
};
